'use client';

import { projectsData } from '@/lib/portfolio-data';
import { SectionHeader } from './section-header';

export function Projects() {
  const featuredProject = projectsData.find((p) => p.featured);
  const otherProjects = projectsData.filter((p) => !p.featured);

  return (
    <section id="projects" className="px-10">
      <SectionHeader title="projects" />

      <div className="grid grid-cols-2 gap-2.5">
        {/* Featured Project */}
        {featuredProject && (
          <div className="col-span-2 border border-[#27272a]/50 rounded-[10px] p-5 relative">
            <div className="absolute top-3.5 right-3.5 font-mono text-[9px] text-[#4ade80] border border-[#4ade80]/20 bg-[#4ade80]/5 px-2 py-[3px] rounded">
              featured
            </div>

            <div className="text-sm font-semibold text-[#e4e4e7] mb-[7px]">
              {featuredProject.title}
            </div>

            <div className="text-xs text-[#3f3f46] leading-[1.6] mb-2.5">
              {featuredProject.description}
            </div>

            <div className="flex flex-wrap gap-[5px] mb-2.5">
              {featuredProject.tags.map((tag) => (
                <span
                  key={tag}
                  className="font-mono text-[9px] text-[#3f3f46] bg-[#18181b] px-[7px] py-[3px] rounded"
                >
                  {tag}
                </span>
              ))}
            </div>

            <div className="flex gap-3">
              {featuredProject.links.map((link) => (
                <button
                  key={link.label}
                  onClick={() => window.open(link.href, '_blank')}
                  className="font-mono text-[11px] text-[#27272a] hover:text-[#4ade80] transition-colors cursor-pointer"
                >
                  ⌥ {link.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Other Projects */}
        {otherProjects.map((project) => (
          <div
            key={project.title}
            className="border border-[#1a1a1e] rounded-[10px] p-4"
          >
            <div className="text-sm font-semibold text-[#e4e4e7] mb-[7px]">
              {project.title}
            </div>

            <div className="text-xs text-[#3f3f46] leading-[1.6] mb-2.5">
              {project.description}
            </div>

            <div className="flex flex-wrap gap-[5px] mb-2.5">
              {project.tags.map((tag) => (
                <span
                  key={tag}
                  className="font-mono text-[9px] text-[#3f3f46] bg-[#18181b] px-[7px] py-[3px] rounded"
                >
                  {tag}
                </span>
              ))}
            </div>

            <div className="flex gap-3">
              {project.links.map((link) => (
                <button
                  key={link.label}
                  onClick={() => window.open(link.href, '_blank')}
                  className="font-mono text-[11px] text-[#27272a] hover:text-[#4ade80] transition-colors cursor-pointer"
                >
                  ⌥ {link.label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
