import { experienceData } from '@/lib/portfolio-data';
import { SectionHeader } from './section-header';

export function Experience() {
  return (
    <section id="experience" className="px-10">
      <SectionHeader title="experience" />

      <div className="space-y-7">
        {experienceData.map((exp, idx) => (
          <div key={idx} className="grid grid-cols-[90px_1fr]">
            {/* Timeline */}
            <div className="font-mono text-[10px] text-[#27272a] text-right pr-5 pt-[3px] leading-[1.9]">
              {exp.startDate}
              <br />
              —
              <br />
              {exp.endDate}
            </div>

            {/* Content */}
            <div className="border-l border-[#27272a]/50 pl-5 relative">
              {/* Node */}
              <div
                className={`absolute left-[-5px] top-[5px] w-2 h-2 rounded-full bg-[#09090b] border-[1.5px] ${
                  exp.isCurrent ? 'border-[#4ade80]' : 'border-[#27272a]'
                }`}
              ></div>

              <div className="text-sm font-semibold text-[#f4f4f5]">
                {exp.role}
              </div>

              <div className="font-mono text-xs text-[#4ade80] mt-[3px] mb-1 flex items-center gap-2">
                {exp.company}
                <span className="text-[9px] text-[#3f3f46] bg-[#18181b] border border-[#27272a]/50 px-[7px] py-[2px] rounded">
                  {exp.type}
                </span>
              </div>

              {exp.bullets.map((bullet, bulletIdx) => (
                <div
                  key={bulletIdx}
                  className="flex gap-[7px] text-xs text-[#52525b] leading-[1.65] mb-[3px]"
                >
                  <span className="text-[#4ade80] opacity-35 flex-shrink-0">
                    ›
                  </span>
                  <span>{bullet}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
