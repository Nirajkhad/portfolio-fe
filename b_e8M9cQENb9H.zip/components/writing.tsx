'use client';

import { postsData } from '@/lib/portfolio-data';
import { SectionHeader } from './section-header';

export function Writing() {
  return (
    <section id="writing" className="px-10">
      <SectionHeader title="writing" />

      <div className="flex flex-col gap-2">
        {postsData.map((post, idx) => (
          <article
            key={idx}
            onClick={() => window.open(post.href, '_blank')}
            className="border border-[#1a1a1e] rounded-[10px] px-[18px] py-4 flex justify-between items-start gap-3 cursor-pointer hover:border-[#27272a] transition-colors"
          >
            <div className="flex-1">
              {/* Tags */}
              <div className="flex gap-[5px] mb-[7px]">
                {post.tags.map((tag) => (
                  <span
                    key={tag.label}
                    className={`font-mono text-[9px] px-[7px] py-[2px] rounded ${
                      tag.variant === 'accent'
                        ? 'text-[#4ade80] border border-[#4ade80]/20 bg-[#4ade80]/5'
                        : 'text-[#3f3f46] bg-[#18181b] border border-[#27272a]'
                    }`}
                  >
                    {tag.label}
                  </span>
                ))}
              </div>

              {/* Title */}
              <h3 className="text-[13px] font-semibold text-[#d4d4d8] mb-[5px] leading-[1.4]">
                {post.title}
              </h3>

              {/* Excerpt */}
              <p className="text-[11px] text-[#3f3f46] leading-[1.6] mb-2">
                {post.excerpt}
              </p>

              {/* Meta */}
              <div className="font-mono text-[10px] text-[#27272a] flex gap-3">
                <span>{post.date}</span>
                <span>{post.readTime}</span>
              </div>
            </div>

            {/* Arrow */}
            <span className="text-[13px] text-[#27272a] mt-[2px]">↗</span>
          </article>
        ))}
      </div>
    </section>
  );
}
