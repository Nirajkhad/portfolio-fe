'use client';

import { heroData } from '@/lib/portfolio-data';

export function Hero() {
  const { kicker, name, role, bio, location, ctaButtons } = heroData;

  return (
    <section id="home" className="pt-[52px] px-10">
      {/* Kicker line */}
      <div className="flex items-center gap-2 mb-3">
        <div className="h-px w-7 bg-[#4ade80] opacity-40"></div>
        <p className="font-mono text-[11px] text-[#4ade80] tracking-[0.08em]">
          {kicker}
        </p>
      </div>

      {/* Name */}
      <h1
        className="text-[56px] font-bold text-[#fafafa] leading-none"
        style={{ letterSpacing: '-0.04em' }}
      >
        {name}
      </h1>

      {/* Role */}
      <p className="font-mono text-lg text-[#3f3f46] mt-2 mb-5">{role}</p>

      {/* Bio */}
      <p className="text-sm text-[#71717a] leading-[1.8] mb-5 max-w-[500px]">
        {bio}
      </p>

      {/* Location */}
      <div className="flex items-center gap-[7px] mb-6 font-mono text-[11px] text-[#27272a]">
        <span className="w-1.5 h-1.5 bg-[#4ade80] rounded-full animate-pulse opacity-60"></span>
        <span>{location}</span>
      </div>

      {/* CTA Buttons */}
      <div className="flex gap-3 flex-wrap">
        {ctaButtons.map((btn, idx) => (
          <button
            key={idx}
            onClick={() => {
              if (btn.isExternal) {
                window.open(btn.href, '_blank', 'noopener,noreferrer');
              } else {
                window.location.href = btn.href;
              }
            }}
            className={`font-mono text-[11px] px-3.5 py-[7px] rounded-md transition-all duration-200 inline-flex items-center gap-[7px] cursor-pointer ${
              btn.variant === 'primary'
                ? 'bg-[#4ade80] text-[#09090b] font-semibold hover:bg-[#22c55e]'
                : 'border border-[#27272a]/50 text-[#52525b] hover:text-[#4ade80] hover:border-[#4ade80]'
            }`}
          >
            <span>{btn.icon}</span>
            <span>{btn.label}</span>
          </button>
        ))}
      </div>
    </section>
  );
}
