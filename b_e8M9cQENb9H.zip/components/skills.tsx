import { skillsData } from '@/lib/portfolio-data';
import { SectionHeader } from './section-header';

const colorMap = {
  green: 'text-[#86efac] bg-[#0d1f14] border-[#1a3a22]',
  teal: 'text-[#5eead4] bg-[#0a1e1a] border-[#133028]',
  blue: 'text-[#93c5fd] bg-[#0d1829] border-[#162340]',
  amber: 'text-[#fcd34d] bg-[#1a1408] border-[#2e2210]',
  purple: 'text-[#c4b5fd] bg-[#160f28] border-[#271a40]',
  zinc: 'text-[#a1a1aa] bg-[#18181b] border-[#27272a]',
};

export function Skills() {
  return (
    <section id="skills" className="px-10">
      <SectionHeader title="skills" />

      <div className="flex flex-col gap-3.5">
        {skillsData.map((category) => (
          <div
            key={category.category}
            className="grid grid-cols-[90px_1fr] gap-4 items-start"
          >
            <div className="font-mono text-[10px] text-[#27272a] text-right">
              {category.category}
            </div>

            <div className="flex flex-wrap gap-1.5">
              {category.skills.map((skill) => (
                <span
                  key={skill.name}
                  className={`text-xs font-medium px-[11px] py-1 rounded-md border ${colorMap[skill.color]}`}
                >
                  {skill.name}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
